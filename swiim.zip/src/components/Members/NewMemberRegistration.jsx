import React, { useState } from 'react';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import "./NewMemberRegistration.css"

const NewMemberRegistration = () => {
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');
  const [contact, setContact] = useState('');
  const [actualAmount, setActualAmount] = useState(0);
  const [discount, setDiscount] = useState(0);
  const [discountedAmount, setDiscountedAmount] = useState(0);
  const [roundedAmount, setRoundedAmount] = useState(0); // New state for rounded amount

  const handleSendOtp = () => {
    if (contact.length === 10) {
      toast.success(`OTP sent to +91${contact}`, { autoClose: 2000 });
      setOtpSent(true);
    } else {
      toast.error('Please enter a valid 10-digit phone number.', { autoClose: 2000 });
    }
  };

  const handleVerifyOtp = () => {
    if (otp) {
      toast.success('OTP verified successfully!', { autoClose: 2000 });
    } else {
      toast.error('Please enter the OTP.', { autoClose: 2000 });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success('Form submitted successfully!', { autoClose: 2000 });
  };

  // Handle changes to actual amount and discount
  const handleActualAmountChange = (e) => {
    const value = parseFloat(e.target.value);
    setActualAmount(value);
    calculateDiscountedAmount(value, discount);
  };

  const handleDiscountChange = (e) => {
    const value = parseFloat(e.target.value);
    setDiscount(value);
    calculateDiscountedAmount(actualAmount, value);
  };

  const calculateDiscountedAmount = (actualAmount, discount) => {
    if (actualAmount > 0 && discount > 0) {
      const discountAmount = (actualAmount * discount) / 100;
      const discounted = actualAmount - discountAmount;
      setDiscountedAmount(discounted);
      setRoundedAmount(Math.floor(discounted)); // Calculate rounded amount by neglecting decimal values
    } else {
      setDiscountedAmount(actualAmount);
      setRoundedAmount(Math.floor(actualAmount)); // Handle rounding even if there's no discount
    }
  };

  return (
    <div className="registration-container">
      <ToastContainer />
      <div className="registration-form">
        <h2>Member Registration</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-blocks">
            <div className="form-block personal-info">
              <h3>Personal Information</h3>
              <div className="form-group">
                <label htmlFor="firstName">First Name:</label>
                <input type="text" name="firstName" id="firstName" required />
              </div>
              <div className="form-group">
                <label htmlFor="lastName">Last Name:</label>
                <input type="text" name="lastName" id="lastName" required />
              </div>
              <div className="form-group">
                <label htmlFor="contact">Contact:</label>
                <div className="contact-group">
                  <input
                    type="text"
                    name="countryCode"
                    id="countryCode"
                    defaultValue="+91"
                    readOnly
                    className="country-code"
                  />
                  <input
                    type="text"
                    name="contact"
                    id="contact"
                    placeholder="1234567890"
                    required
                    onChange={(e) => setContact(e.target.value)}
                    maxLength={10}
                  />
                </div>
                <button type="button" className="otp-btn" onClick={handleSendOtp}>
                  Send OTP
                </button>
                {otpSent && (
                  <div className="otp-verification">
                    <input
                      type="text"
                      name="otp"
                      id="otp"
                      placeholder="Enter OTP"
                      required
                      onChange={(e) => setOtp(e.target.value)}
                    />
                    <button type="button" onClick={handleVerifyOtp}>
                      Verify OTP
                    </button>
                  </div>
                )}
              </div>
              <div className="form-group">
                <label htmlFor="address">Address:</label>
                <textarea name="address" id="address" rows="4" required></textarea>
              </div>
              <div className="form-group">
                <label htmlFor="gender">Gender:</label>
                <select name="gender" id="gender" required>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="email">Email ID:</label>
                <input type="email" name="email" id="email" required />
              </div>
              <div className="form-group">
                <label htmlFor="dob">Date of Birth:</label>
                <input type="date" name="dob" id="dob" required />
              </div>
              <div className="form-group">
                <label htmlFor="age">Age:</label>
                <input type="number" name="age" id="age" required />
              </div>
              <div className="form-group">
                <label htmlFor="registrationDate">Registration Date:</label>
                <input type="date" name="registrationDate" id="registrationDate" required />
              </div>
            </div>

            <div className="form-block package-info">
              <h3>Package Information</h3>
              <div className="form-group">
                <label htmlFor="packageStartDate">Package Start Date:</label>
                <input type="date" name="packageStartDate" id="packageStartDate" required />
              </div>
              <div className="form-group">
                <label htmlFor="packageActualStartDate">Package Actual Start Date:</label>
                <input type="date" name="packageActualStartDate" id="packageActualStartDate" required />
              </div>
              <div className="form-group">
                <label htmlFor="packageEndDate">Package End Date:</label>
                <input type="date" name="packageEndDate" id="packageEndDate" required />
              </div>
              <div className="form-group">
                <label htmlFor="packageType">Package Type:</label>
                <select name="packageType" id="packageType" required>
                  <option value="basic">Basic</option>
                  <option value="premium">Premium</option>
                </select>
              </div>
            </div>

            <div className="form-block payment-info">
              <h3>Payment Information</h3>
              <div className="form-group">
                <label htmlFor="actualAmount">Actual Amount:</label>
                <div className="amount-input">
                  <span className="currency-symbol">₹</span>
                  <input
                    type="number"
                    name="actualAmount"
                    id="actualAmount"
                    required
                    value={actualAmount}
                    onChange={handleActualAmountChange}
                  />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="discount">Discount (%):</label>
                <input
                  type="number"
                  name="discount"
                  id="discount"
                  value={discount}
                  onChange={handleDiscountChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="discountedAmount">Discounted Amount:</label>
                <div className="amount-input">
                  <span className="currency-symbol">₹</span>
                  <input
                    type="number"
                    name="discountedAmount"
                    id="discountedAmount"
                    readOnly
                    value={discountedAmount}
                  />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="roundedAmount">Rounded Amount:</label>
                <div className="amount-input">
                  <span className="currency-symbol">₹</span>
                  <input
                    type="number"
                    name="roundedAmount"
                    id="roundedAmount"
                    readOnly
                    value={roundedAmount}
                  />
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="transactionId">Transaction ID:</label>
                <input type="text" name="transactionId" id="transactionId" required />
              </div>
              <div className="form-group">
                <label>Payment Type:</label>
                <div>
                  <label>
                    <input type="radio" name="paymentType" value="partial" /> Partial
                  </label>
                  <label>
                    <input type="radio" name="paymentType" value="full" /> Full
                  </label>
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="partialPayment">Partial Payment Amount:</label>
                <input type="number" name="partialPayment" id="partialPayment" />
              </div>
            </div>
          </div>

          <button type="submit" className="submit-btn">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default NewMemberRegistration;
